# الخيل والبارود — Android

نسخة Android من MVP لمنصة الخيل والبارود. التطبيق الحالي يعمل محلياً داخل WebView، ويحتوي على ملفات الويب الأصلية داخل `app/src/main/assets/web/`.

## بناء APK

يتطلب Android Studio أو Android SDK + Gradle.

```bash
gradle assembleDebug
```

سيظهر الملف في:
`app/build/outputs/apk/debug/app-debug.apk`

## البناء التلقائي

يوجد workflow في `.github/workflows/build-apk.yml` لبناء APK عبر GitHub Actions بعد رفع المشروع إلى مستودع GitHub.

## الحزمة

`com.khaylbaroud.app`

## الإصدار

1.0.0
