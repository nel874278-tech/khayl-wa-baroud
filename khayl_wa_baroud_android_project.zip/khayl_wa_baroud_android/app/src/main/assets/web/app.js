const horses=[["العربي الأصيل","سلالة عريقة تتميز بالخفة والتحمل والارتباط بتاريخ الفروسية."],["البربري","من أبرز سلالات الخيل في شمال إفريقيا، وله حضور مهم في التراث المغاربي."],["العربي البربري","سلالة تجمع خصائص العربي والبربري واستُعملت على نطاق واسع في المنطقة."]];
const seasons=[["15 أكتوبر","موسم نموذجي","المغرب","🇲🇦"],["02 نوفمبر","موسم نموذجي","الجزائر","🇩🇿"],["—","أضف موسمًا من لوحة الإدارة","غير محدد","＋"]];
const riders=[["ن","الفارس","اسم الفارس • المنطقة • السربة"],["س","السربة","اسم السربة • قائدها • المنطقة"],["ق","القبيلة","اسم القبيلة • المنطقة • نبذة تراثية"]];
document.getElementById("horseList").innerHTML=horses.map(x=>`<article><div class="avatar">𓃗</div><h3>${x[0]}</h3><p>${x[1]}</p></article>`).join("");
document.getElementById("seasonList").innerHTML=seasons.map(x=>`<div class="season"><div class="date">${x[0]}</div><div><b>${x[1]}</b><br><small>${x[2]}</small></div><span>${x[3]}</span></div>`).join("");
document.getElementById("riderList").innerHTML=riders.map(x=>`<article class="rider"><div class="avatar">${x[0]}</div><h3>${x[1]}</h3><small>${x[2]}</small></article>`).join("");
document.getElementById("mediaGrid").innerHTML=["التبوريدة","الفرسان","الخيل","الموسم","التراث"].map((x,i)=>`<div class="media ${i===0?'big':''}">${x}</div>`).join("");
document.getElementById("joinForm").addEventListener("submit",e=>{e.preventDefault();let f=new FormData(e.target);let arr=JSON.parse(localStorage.getItem("riderRequests")||"[]");arr.push(Object.fromEntries(f));localStorage.setItem("riderRequests",JSON.stringify(arr));e.target.reset();toast("تم حفظ طلبك في النسخة التجريبية. سيظهر في لوحة الإدارة.");});
function toast(t){let x=document.createElement("div");x.className="toast";x.textContent=t;document.body.appendChild(x);setTimeout(()=>x.remove(),3200)}
